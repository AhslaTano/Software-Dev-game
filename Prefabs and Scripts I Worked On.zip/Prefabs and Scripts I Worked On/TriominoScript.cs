using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class Triomino : MonoBehaviour
{
    public TriominoObject triominoData;  // Reference to the ScriptableObject

    private SpriteRenderer spriteRenderer;
    private TextMeshPro[] numberTexts;  // Assume you have text objects for the numbers

    void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        numberTexts = GetComponentsInChildren<TextMeshPro>();  // Assuming numbers are child objects

        UpdateTriomino();
    }

    public void UpdateTriomino()
    {
        if (triominoData != null)
        {
            // Set the color of the Triomino
            //spriteRenderer.color = triominoData.pieceColor;

            // Update the numbers on the sides of the triangle (assuming 3 TextMeshPro children)
            if (numberTexts.Length >= 3)
            {
                numberTexts[0].text = triominoData.top.ToString();
                numberTexts[1].text = triominoData.left.ToString();
                numberTexts[2].text = triominoData.right.ToString();
            }
        }
    }
}

