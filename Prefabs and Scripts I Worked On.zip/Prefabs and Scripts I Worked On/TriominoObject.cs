using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "New Triomino", menuName = "Triominos/Triomino")]
public class TriominoObject : ScriptableObject
{
    // Numbers on each side of the Triomino piece
    public int top;
    public int left;
    public int right;
}
